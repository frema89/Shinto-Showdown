extends Camera2D
